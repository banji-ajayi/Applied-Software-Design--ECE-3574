#include "canvasview.h"
#include <QPainter>
#include <QDebug>
#include <QEvent>
#include "canvas.h"

canvasview::canvasview(QWidget * parent): QWidget(parent)
{
  state = INITIAL;
  shape = UNDEFINED;
  inter = new intermediate();
  start = true;
  show_points = false;
  here = false;
  snapped = false;

  //**for testing******
  key_press_x = false;
  key_press_c = false;
  key_press_esc = false;
  //*******************

  setMouseTracking(true);

  QSize size(width,height);
  setMinimumSize(size);
  setMaximumSize(size);
  setSizePolicy(QSizePolicy(QSizePolicy::Maximum,QSizePolicy::Maximum));
}

void canvasview::paintEvent(QPaintEvent * event)
{
  QPainter *painter = new QPainter(this);

  inter->i_Draw(painter, false, 1); //this prints everything out

  if(state == ACTIVE)
  {
        inter->i_Draw(painter, true, 1);
        if (shape == LINE)
        {
            state = PRESSX;
        }

        if (shape == CIRCLE)
        {
            state = PRESSC;
        }
  }

  if (state == PRESSX || state == PRESSC)
  {
      inter->i_Draw(painter, true, 1);
  }

  if(state == FIRSTCLICK)
  {

      inter->i_Draw(painter, true, 1);
      if (shape == LINE)
      {
        painter->drawLine(st,end);
      }

      if (shape == CIRCLE)
      {
        int length = my_line.length();
        painter->drawEllipse(st, length,length);
      }
  }

  if (state == SECONDCLICK)
  {
      inter->set_bool_snap(false);
      state = RESET;
  }

  if(state == RESET)
  {
    start = false;
    show_points = false;
    snapped = false;
    emit this->send_highlight(false,false,false);
    state = INITIAL;
    shape = UNDEFINED;
  }

  update();
}


void canvasview::keyPressEvent(QKeyEvent *event)
{
    if (state == INITIAL)//this means nothin has been pressed
    {
        if (event->key() == Qt::Key_C)
        {
            key_press_c = true;
            emit this->send_highlight(true,false,false);
            state = ACTIVE;
            shape = CIRCLE;
            start = true;
            show_points = true;
        }

        else if (event->key() == Qt::Key_X)
        {
            key_press_x = true;
            emit this->send_highlight(false,true,false);
            shape = LINE;
            state = ACTIVE;
            start = true;
            show_points = true;
        }
    }

    if (event->key() == Qt::Key_Escape)
    {
        key_press_esc = true;
        emit this->send_highlight(false,false,false);
        QString nothing;
        bool do_nothing;
        emit this->change_str(do_nothing);
        emit this->send_points(SECONDCLICK,QPointF(0,0),UNDEFINED,nothing);
        state = SECONDCLICK;
        start = false;
        show_points = false;
    }

    else
    {
        event->ignore();
    }

    update();
}


void canvasview::mousePressEvent(QMouseEvent *event)
{
    if (start)
    {
        if(state == PRESSX || state == PRESSC)
        {
            state = FIRSTCLICK;
            if (snapped)
                st = snap_points;
            else
                st = QPointF(pointx, pointy);
            my_line.setP1(st);
        }

        else if(state == FIRSTCLICK)
        {
            state = SECONDCLICK;
            start = false;
            if (snapped)
                end = snap_points;
            else
                end = QPointF(pointx, pointy);

            inter->add_shape(shape, st, end);
        }
    }

}

void canvasview::mouseMoveEvent(QMouseEvent *event)
{
    QString temp;
    pointx = event->x();
    pointy = event->y();
    end = QPointF(pointx,pointy);
    my_line.setP2(end);
    bool canvas_points = false;
    if(show_points)
    {
        if (state == FIRSTCLICK)
        {
            snap_points = QPointF(pointx, pointy);
            if (inter->snap_point(snap_points, temp, canvas_points))
            {
                snapped = true;
                //add a string argument so that you can pass the temp string
                emit this->change_str(true);
                emit this->send_points(FIRSTCLICK, snap_points, shape, temp);
            }
            else
            {
                emit this->change_str(false);
                emit this->send_points(FIRSTCLICK, snap_points, shape, temp);
            }

        }
        else if(state == PRESSX)
        {
            snap_points = QPointF(pointx, pointy);
            if (inter->snap_point(snap_points, temp, canvas_points))
            {
                snapped = true;
                //add a string argument so that you can pass the temp string
                emit this->change_str(true);
                emit this->send_points(PRESSX, snap_points, shape, temp);
            }
            else
            {
                emit this->change_str(false);
                emit this->send_points(PRESSX, snap_points, shape, temp);
            }


        }

        else if(state == PRESSC)
        {
            snap_points = QPointF(pointx, pointy);
            if (inter->snap_point(snap_points, temp, canvas_points))
            {
                snapped = true;
                QString write = temp;
                //add a string argument so that you can pass the temp string
                emit this->change_str(true);
                 emit this->send_points(PRESSC, snap_points, shape, write);
            }
            else
            {
                emit this->change_str(false);
                emit this->send_points(PRESSC, snap_points, shape, temp);
            }

        }
    }


    update();
}

//**************************************
//****TESTING FUNCTIONS*****************

void canvasview::set_state(statetype st)
{
    state = st;
}

void canvasview::set_show_points_bool(bool sp)
{
    show_points = sp;
}

bool canvasview::get_key_x()
{
    return key_press_x;
}

bool canvasview::get_key_c()
{
    return key_press_c;
}

bool canvasview::get_key_esc()
{
    return key_press_esc;
}

int canvasview::getx()
{
    return pointx;
}

int canvasview::gety()
{
    return pointy;
}

void canvasview::return_inter(intermediate *i)
{
    i = inter;
}

//**************************************
//**************************************
