#include "circle.h"
#include <QLineF>


circle::circle(QPointF p1, QPointF p2)
{
    point1 = p1;
    point2 = p2;

    length_line.setP1(point1);
    length_line.setP2(point2);
    length = length_line.length();

    hs = 10;
    center = point1;
    cright = QPointF(point1.rx()+length,point1.ry());
    cleft = QPointF(point1.rx()-length,point1.ry());
    cbot = QPointF(point1.rx(),point1.ry()+length);
    ctop = QPointF(point1.rx(),point1.ry()-length);
    snapper = false;
}

void circle::draw(QPainter *painter, bool active, int shape)
{
    painter->drawEllipse(point1, length, length);


        if(active)
        {
            send_point(center, cright, cleft);
            use_handle(&(*painter), 2);
            send_point(cbot, ctop, center);
            use_handle(&(*painter), 3);
        }

        if(snapper)
            do_snap(&(*painter), this->highlight_point);
}

bool circle::snap(QPointF &point, QString &where, bool &canvas_points, bool &circle_point)
{
    //if point distance is less than hs then its inside the circle so switch points
    //and return a string
    canvas_points = false;
    if (distance(point, this->center) < hs)
    {
        point = this->center;
        highlight_point = this->center;
        where = "Circle's center";
        snapper = true;
        circle_point = true;
        return true;
    }
    else if(distance(point, this->ctop) < hs)
    {
        point = this->ctop;
        highlight_point = this->ctop;
        where = "Circle's top";
        circle_point = true;
        snapper = true;
        return true;
    }
    else if(distance(point, this->cbot) < hs)
    {
        point = this->cbot;
        highlight_point = this->cbot;
        where = "Circle's bottom";
        circle_point = true;
        snapper = true;
        return true;
    }
    else if(distance(point, this->cright) < hs)
    {
        point = this->cright;
        highlight_point = this->cright;
        where = "Circle's right";
        circle_point = true;
        snapper = true;
        return true;
    }
    else if(distance(point, this->cleft) < hs)
    {
        point = this->cleft;
        highlight_point = this->cleft;
        where = "Circle's left";
        circle_point = true;
        snapper = true;
        return true;
    }

    else
    {
        circle_point = false;
        snapper = false;
        return false;
    }

}

void circle::set_snap(bool snap)
{
    snapper = snap;
}

int circle::p1x()
{
    return this->point1.rx();
}

int circle::p1y()
{
    return this->point1.ry();
}

int circle::p2x()
{
    return this->point2.rx();
}

int circle::p2y()
{
    return this->point2.ry();
}

int circle::get_length()
{
    return this->length;
}
