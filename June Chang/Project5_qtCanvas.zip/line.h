#ifndef LINE_H
#define LINE_H

#include "object.h"
#include <QPainter>
#include <QPointF>
#include <QLineF>



class line : public object
{
public:
    line();
    line(QPointF p1, QPointF p2);
    virtual void draw(QPainter *painter, bool active, int shape);
    virtual bool snap(QPointF &point, QString &where, bool &canvas_points, bool &circle_point);
    virtual void set_snap(bool snap);
    int point_1x();
    int point_1y();
    int point_2x();
    int point_2y();

private:
    QPointF point1, point2;
    QPointF highlight_point;
    QPointF botPoint;
    QPointF topPoint;
    int hs;
    bool snapped;
    QLineF point_distance;
};


#endif

