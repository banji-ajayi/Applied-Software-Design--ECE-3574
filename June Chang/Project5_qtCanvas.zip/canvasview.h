#ifndef CANVASVIEW_H
#define CANVASVIEW_H

typedef enum statetype{INITIAL, ACTIVE, PAUSE, PRESSX, PRESSC, FIRSTCLICK,
                       SECONDCLICK, RESET} statetype;
typedef enum shapetype{CIRCLE,LINE,UNDEFINED} shapetype;

#include <QWidget>
#include <QSize>
#include <QPointF>
#include <QPoint>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QString>
#include "object.h"
#include "canvas.h"
#include "intermediate.h"
#include "mainwindow.h"
#include <QLineF>

class intermediate;

class canvasview : public QWidget
{
  Q_OBJECT

  public:

    canvasview(QWidget *parent = 0);

    void paintEvent(QPaintEvent * event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent *event);

//*******TESTING FUNCTIONS**********
    void set_state(statetype st);
    void set_show_points_bool(bool sp);
    bool get_key_x();
    bool get_key_c();
    bool get_key_esc();
    int getx();
    int gety();
    void return_inter(intermediate *i);
//**********************************

signals:
    void send_highlight(bool c, bool x, bool e);
    void send_points(statetype state, QPointF, shapetype sh, QString point_m);
    void change_str(bool change);

  private:
    statetype state;
    shapetype shape;
    static const int width = 900;//mid points 450
    static const int height = 720; //mid point 360
    intermediate *inter;
    QPointF st, end;
    QPointF snap_points;
    int pointx, pointy;
    int p1,p2;
    QLineF my_line;
    bool start, show_points;
    bool here, snapped;
    bool key_press_x, key_press_c, key_press_esc;

  };


#endif
