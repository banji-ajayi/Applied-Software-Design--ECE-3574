#include "message.h"
#include <QPainter>

#include <QDebug>
message::message(QWidget *parent) : QWidget(parent)
{
    width = tempC.get_width()/2;
    height = tempC.get_height()/2;
    QSize size(900,65);
    setMinimumSize(size);
    setMaximumSize(size);
    setSizePolicy(QSizePolicy(QSizePolicy::Maximum,QSizePolicy::Maximum));
}

void message::paintEvent(QPaintEvent *event)
{
    QPainter *paint = new QPainter(this);
    paint->drawText(0,0,900,65,Qt::AlignCenter, coordinates);
    update();
}
void message::str_change(bool change)
{
    str_changed = change;
}

void message::showme(statetype state, QPointF point, shapetype sh, QString point_m)
{
    if(state == FIRSTCLICK)
    {
        QString x_point2 = QString::number(point.x()-width);
        QString y_point2 = QString::number(height-point.y());
        if (sh == LINE)
        {
            coordinates = "Draw line from " + first_co +" to ";
            if(str_changed)
                coordinates = coordinates  + point_m;
            else
                coordinates = coordinates + "(" + x_point2 + ", "+ y_point2 + ")";

        }

        if (sh == CIRCLE)
        {
            coordinates = "Draw circle centered at " + first_co +" and passing through ";
            if(str_changed)
                coordinates = coordinates + point_m;
            else
                coordinates = coordinates +"(" + x_point2 + ", "+ y_point2 + ")";
        }
    }

    if(state == PRESSX)
    {
        x_point = QString::number(point.x()-width);
        y_point = QString::number(height-point.y());

        if(str_changed)
            first_co = point_m;

        else
            first_co = "("+x_point +", "+y_point+")";

        coordinates = "Draw line from " + first_co + " to ...";

    }

    if(state == PRESSC)
    {
        x_point = QString::number(point.x()-width);
        y_point = QString::number(height-point.y());

        if(str_changed)
            first_co = point_m;

        else
            first_co = "("+x_point +", "+y_point+")";

        coordinates = "Draw circle centered at " + first_co + " and passing through ...";
    }

    if(state == SECONDCLICK)
    {
        coordinates = "";
    }
   emit this->update();
}

QString message::get_coor()
{
    return coordinates;
}
