#ifndef OBJECT_H
#define OBJECT_H

#include <QPainter>
#include <QPointF>
#include <QString>
#include <QLineF>


class object
{
public:
    object();
    virtual void draw(QPainter* painter, bool active, int shape) = 0;
    virtual qreal distance(QPointF st, QPointF end);
    virtual bool snap(QPointF &point, QString &where, bool &canvas_points, bool &circle_point) = 0;
    virtual void set_snap(bool set_snap) = 0;
    virtual void use_handle(QPainter* painter, int shape);
    virtual void send_point(QPointF p1, QPointF p2, QPointF p3);
    virtual void do_snap(QPainter *painter, QPointF p1);
    void draw_handle1(QPainter* painter);
    void draw_handle2(QPainter* painter);

private:
    int hl;
    QPointF point1,
            point2,
            point3;
    QLineF point_distance;


};
#endif
