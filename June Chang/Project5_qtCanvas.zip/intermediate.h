#ifndef INTERMEDIATE_H
#define INTERMEDIATE_H

#include "canvas.h"
#include "object.h"
#include <QVector>
#include "canvasview.h"


class object;

class intermediate
{
public :
    intermediate();
    void i_Draw(QPainter *painter, bool active, int shape);
    void add_shape(shapetype add_shape, QPointF p1, QPointF p2);
    bool snap_point(QPointF &st_point, QString &where, bool &canvas_points);
    void set_bool_snap(bool snapper);
    int get_vector_size();

    int p1x();
    int p1y();

private:
    QVector <object *> my_vector;
    int l_t_p1x;
    int l_t_p1y;
};


#endif
