#include "object.h"

object::object()
{
    hl = 10;
}

void object::use_handle(QPainter *painter, int shape)
{
    painter->save();
    painter->setBrush(Qt::yellow);
    painter->setPen(Qt::blue);
    if(shape == 1 || shape == 2)
        draw_handle1(&(*painter));
    else if(shape == 3)
        draw_handle2(&(*painter));
    else if(shape == 4)
        draw_handle2(&(*painter));

    painter->restore();
}

void object::do_snap(QPainter *painter, QPointF p1)
{
    painter->save();
    painter->setBrush(Qt::blue);
    painter->setPen(Qt::blue);
    painter->drawEllipse(p1, hl,hl);
    painter->restore();
    painter->drawEllipse(p1, hl+8, hl+8);
}

void object::send_point(QPointF p1, QPointF p2, QPointF p3)
{
    point1 = p1;
    point2 = p2;
    point3 = p3;
}

void object::draw_handle1(QPainter *painter)
{
    painter->drawEllipse(point1, hl, hl);
    painter->drawEllipse(point2, hl, hl);
    painter->drawEllipse(point3,hl, hl);
}

void object::draw_handle2(QPainter *painter)
{
    painter->drawEllipse(point1, hl, hl);
    painter->drawEllipse(point2, hl, hl);
}

qreal object::distance(QPointF st, QPointF end)
{
    point_distance.setP1(st);
    point_distance.setP2(end);
    return point_distance.length();
}
