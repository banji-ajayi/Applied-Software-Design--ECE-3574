#ifndef TESTALL_H
#define TESTALL_H

#include <QDebug>
#include <QPointF>
#include <QLineF>
#include <QKeyEvent>
#include <QEvent>
//#include <QTest>
#include <QPaintEvent>
#include <QPixmap>

#include "intermediate.h"
#include "canvasview.h"
#include "line.h"
#include "circle.h"
#include "canvas.h"
#include "message.h"
#include "menu.h"


/*
class intermediate;
class line;
class circle;
class canvasview;
class message;
class menu;


void test_draw(intermediate *i)
{
    qDebug() << "TEST: Create a line";
    QPointF test_p1 = QPointF(10,16);
    QPointF test_p2 = QPointF(300,350);

    QLineF test_line;
    test_line.setP1(test_p1);
    test_line.setP2(test_p2);
    int test_length = test_line.length();

    line* tl = new line(test_p1, test_p2);

    assert(tl->point_1x() == 10);
    assert(tl->point_1y() == 16);
    assert(tl->point_2x() == 300);
    assert(tl->point_2y() == 350);

    qDebug() <<"TEST: Create a circle - check for radius";
    circle* tc = new circle(test_p1, test_p2);
    assert(tc->p1x() == 10);
    assert(tc->p1y() == 16);
    assert(tc->p2x() == 300);
    assert(tc->p2y() == 350);
    assert(tc->get_length() == test_length);

    delete tl;
    delete tc;
}

void test_drawing_area()
{
    canvasview *test_canvas = new canvasview();

    test_canvas->set_state(INITIAL);
    qDebug() << "TEST: Send Key X";
    QTest::keyPress(test_canvas, Qt::Key_X);
    assert(test_canvas->get_key_x() == true);

    test_canvas->set_state(INITIAL);
    qDebug() << "TEST: Send Key C";
    QTest::keyPress(test_canvas, Qt::Key_C);
    assert(test_canvas->get_key_c() == true);

    test_canvas->set_state(INITIAL);
    qDebug() << "TEST: Send Key ESC";
    QTest::keyPress(test_canvas, Qt::Key_Escape);
    assert(test_canvas->get_key_esc() == true);


    delete test_canvas;
}

void test_message_area()
{
    message *test_message = new message();
    qDebug() << "TEST: Message Area";
    test_message->showme(PRESSX, 20, 15, LINE, "", false);
    assert(test_message->get_coor() == "Draw line from (-415, 335) to ...");

    test_message->showme(PRESSX, 20, 15, LINE, "end of line", true);
    assert(test_message->get_coor() == "Draw line from end of line to ...");

    test_message->showme(FIRSTCLICK, 20, 15, LINE, "Canvas's center", true);
    assert(test_message->get_coor() == "Draw line from end of line to Canvas's center" );

    test_message->showme(PRESSC, 20, 15, CIRCLE, "Canvas's center", true);
    assert(test_message->get_coor() == "Draw circle centered at Canvas's center and passing through ..." );

    test_message->showme(PRESSC, 20, 15, CIRCLE, "Canvas's center", false);
    assert(test_message->get_coor() == "Draw circle centered at (-415, 335) and passing through ..." );

    test_message->showme(FIRSTCLICK, 20, 15, CIRCLE, "end of line", true);
    assert(test_message->get_coor() == "Draw circle centered at (-415, 335) and passing through end of line" );
}

void test_menu_area()
{
    menu *test_menu = new menu();
    qDebug() << "TEST: Menu Area";

    test_menu->receive_highlights(true, false, true);
    assert(test_menu->get_c() == true && test_menu->get_x() == false && test_menu->get_esc() == true);
    delete test_menu;
}

void test_pixmap()
{

    canvasview *test_canvas = new canvasview();
    QPainter *painter = new QPainter(test_canvas);
    intermediate *iter = new intermediate();
    test_canvas->show();
    /*
    test_canvas->set_show_points_bool(RESET);
    QTest::keyPress(test_canvas, Qt::Key_C);
    QTest::mouseMove(test_canvas);
    QTest::mouseClick(test_canvas, Qt::LeftButton);
    QTest::mouseMove(test_canvas, QPoint(500, 100));
    QTest::mouseClick(test_canvas, Qt::LeftButton);
   //
   //   /*
    test_canvas->set_show_points_bool(INITIAL);
    QTest::keyPress(test_canvas, Qt::Key_C);
    QTest::mouseMove(test_canvas);
    QTest::mouseClick(test_canvas, Qt::LeftButton);
    QTest::mouseMove(test_canvas, QPoint(500, 100), -100);
    QTest::mouseClick(test_canvas, Qt::LeftButton);
    //
    test_canvas->return_inter(iter);
    iter->add_shape(LINE, QPointF(0,0), QPointF(500,300));
    qDebug() << iter->get_vector_size();
    iter->i_Draw(painter, false);

    QPixmap::grabWidget(test_canvas);
   // delete test_canvas;
   // delete painter;
}


*/
#endif
