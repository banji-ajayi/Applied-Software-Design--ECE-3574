#include "line.h"
#include <QBrush>
#include <QDebug>
line::line()
{

}

line::line(QPointF p1, QPointF p2)
{
    point1 = p1;
    point2 = p2;
    snapped = false;
    botPoint = p1;
    topPoint = p2;
    hs = 10;
}

void line::draw(QPainter *painter, bool active, int shape)
{
    //botPoint = this->point1;
    //topPoint = this->point2;
    painter->drawLine(this->point1, this->point2);
    if(active)
    {
        send_point(this->point1, this->point2, this->point2);
        use_handle(&(*painter), 4);
    }

    if(snapped)
        do_snap(&(*painter), this->highlight_point);
}

bool line::snap(QPointF &point, QString &where, bool &canvas_points, bool &circle_point)
{
    //if point distance is less than hs then its inside the circle so switch points
    //and return a string
    circle_point = false;
    if (distance(point, this->botPoint) < hs)
    {
        point = this->botPoint;
        highlight_point = this->botPoint;
        where = "end of line";
        snapped = true;
        canvas_points = false;
        return true;
    }
    else if(distance(point, this->topPoint) < hs)
    {
        point = this->topPoint;
        highlight_point = this->topPoint;
        where = "end of line";
        canvas_points = false;
        snapped = true;
        return true;
    }
    else
    {
        snapped = false;
        canvas_points = false;
        return false;
    }

}

void line::set_snap(bool snap)
{
    snapped = snap;
}

int line::point_1x()
{
    return this->point1.rx();
}

int line::point_1y()
{
    return this->point1.ry();
}

int line::point_2x()
{
    return this->point2.rx();
}

int line::point_2y()
{
    return this->point2.ry();
}

