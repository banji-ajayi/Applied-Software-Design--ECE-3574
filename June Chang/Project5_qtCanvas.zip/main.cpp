#include <QApplication>

#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);

    mainwindow view;
    //test();
    view.show();
    return application.exec();
}
